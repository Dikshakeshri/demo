package com.nttdata;

import java.util.Scanner;

public class Greet {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner sc=new Scanner(System.in);
System.out.println("Enter name");
String n=sc.nextLine();
System.out.println("welocme to github :" +n);
	}

}
